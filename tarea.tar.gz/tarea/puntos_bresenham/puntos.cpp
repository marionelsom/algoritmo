/*Creado por Mario Nelson Torres Mena*/
/*Fecha 18 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void puntos(GLfloat x, GLfloat y, GLfloat r, GLfloat g, GLfloat b){
  //recibe valores de x,y && valores de color en r,g,b
  glPointSize(6.0f);
  glBegin(GL_POINTS);
  glColor3f(r,g,b);
  glVertex2f(x,y);
  glEnd();
}
void Lineas(GLfloat xp1, GLfloat yp1, GLfloat xp2, GLfloat yp2) {
  //recibe los dos puntos (x,y,z) (x,y,z)
  glBegin(GL_LINES);
  glColor3f(1.0,1.0,1.0);
  glVertex2f(xp1,yp1);
  glVertex2f(xp2,yp2);
  glEnd();
}
void display(void)
{
	  glClearColor(0.45, 0.40, 0.40,0.0);
    glClear(GL_COLOR_BUFFER_BIT);

    Lineas(-4,0, 4,0);
    Lineas(0,-4, 0,4);

    GLfloat xinicio=-4;
    GLfloat yinicio=-4;
    GLfloat xfin=4;
    GLfloat yfin=4;
    GLfloat x=0;
    GLfloat y=0;
    GLfloat deltax;
    GLfloat deltay;
    GLfloat constanteP;
    GLfloat ultimo;

    GLfloat x1=-4;
    GLfloat y2=-4;

    deltax = abs(xfin-xinicio);
    deltay = abs(yfin-yinicio);
    constanteP= 2*deltay-deltax;
    if(xinicio>xfin){
      x= xfin;
      y=yfin;
      ultimo = xinicio;
    }else{
      x = xinicio;
      y=yinicio;
      ultimo = xfin;
    }
    puntos(x,y, 0.0,0.0,1.0);

    while(x<ultimo){
      x+=.1;
      if(constanteP<0){
        constanteP+=2*deltay;
      }else{
        y+=.1;
        constanteP +=2*(deltay-deltax);
      }
      puntos(x,y, 0.0,0.0,1.0);
    }

    Lineas(x1,y2, x,y);
    glFlush ();
}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-4.0, 4.0, -4.0, 4.0, -4.0, 4.0);
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 420);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Punto Bresenham");
    init ();

    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
