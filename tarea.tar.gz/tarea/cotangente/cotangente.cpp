/*Creado por Mario Nelson Torres Mena*/
/*Fecha 23 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
float limites = 5;
void puntos(GLfloat x, GLfloat y, GLfloat r, GLfloat g, GLfloat b){
  //recibe valores de x,y && valores de color en r,g,b 
  glPointSize(1.0f);
  glBegin(GL_POINTS);
  glColor3f(r,g,b);
  glVertex2f(x,y);
  glEnd();
}
void Lineas(GLfloat xp1, GLfloat yp1, GLfloat xp2, GLfloat yp2) {
  //recibe los dos puntos (x,y,z) (x,y,z)
  glBegin(GL_LINES);
  glColor3f(1.0,1.0,1.0);
  glVertex2f(xp1,yp1);
  glVertex2f(xp2,yp2);
  glEnd();
}
void display(void)
{
	  glClearColor(0.45, 0.40, 0.40,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    //plano
    Lineas((limites),0.0f, -(limites),-0.0f);
    Lineas(0.0f,(limites), 0.0f,-(limites));

    double i =-3*M_PI;
    while (i<=(3*M_PI)) {
      double y=1/(tan(i));
      puntos(i,y, 0.0,0.0,1.0);
      i+=0.01;
    }
    glFlush ();
}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(limites), (limites), -(limites), (limites), -(limites), (limites));
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 420);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Cotangente");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
