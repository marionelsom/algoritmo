/*Creado por Mario Nelson Torres Mena*/
/*Fecha 22 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;

void Lineas(GLfloat xp1, GLfloat yp1, GLfloat xp2, GLfloat yp2) {
  //recibe los dos puntos (x,y,z) (x,y,z)
  glBegin(GL_LINES);
  glColor3f(0.0,0.0,0.0);
  glVertex2f(xp1,yp1);
  glVertex2f(xp2,yp2);
  glEnd();
}
void Puntos(GLfloat xp1, GLfloat yp1) {
  //recibe puntos (x,y,z) (x,y,z)
  glPointSize(2.0f);
  glBegin(GL_POINTS);
  glColor3f(1.0,0.0,0.0);
  glVertex2f(xp1,yp1);
  glEnd();
}
void display(void)
{
	glClearColor(0.2,0.2,0.2,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
//cancha
    //plano
    Lineas(-(6.0*M_PI),0.0f, (6.0*M_PI),-0.0f);
    Lineas(0.0f,(6.0*M_PI),0.0f,-(6.0*M_PI));

float px=0;
float k = 2;
float py=0;
float var1, var2,var3,var4,var5;

    float i = -3*M_PI;
    while (i<=(5*M_PI)) {
      px = i;
      var1 = k;
      var2 = (4*k)/M_PI;
      var3 = sin(px);
      var4 = (1/3)*sin(3*px);
      var5 = (1/5)*sin(5*px);
      py = var1 + var2*(var3 + var4 + var5);
      glBegin(GL_LINES);
      glColor3f(0.0,0.0,0.0);
      glVertex2f(px,py);
      glVertex2f(px,0);
      glVertex2f(px,py);
      i+=(M_PI);
    }
    glEnd();

    px=0;
    k = 2;
    py=0;
    var1=0, var2=0,var3=0,var4=0,var5=0;
    i = -3*M_PI;

    while (i<=(5*M_PI)) {
      px = i;
      var1 = k;
      var2 = (4*k)/M_PI;
      var3 = sin(px);
      var4 = (1/3)*sin(3*px);
      var5 = (1/5)*sin(5*px);
      py = var1 + var2*(var3 + var4 + var5);
      for(float j=0; j<2;j+=0.4){
        Puntos(px,j);
      }
      i+=(M_PI);
    }
    glEnd();


    glFlush ();
}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(6.0*M_PI), (6.0*M_PI), -(6.0*M_PI), (6.0*M_PI), -(6.0*M_PI), (6.0*M_PI));
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 420);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Onda cuadrada");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
