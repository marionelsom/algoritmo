#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>

GLuint texture[0];//la textura
//Definimos variabless
float escala=0.2;
int ResX=1000,ResY=800;

//almacena el index del estado, de la lista
int bola=2;
int mundo=3;

//Definición del modelo de una luz
GLfloat light_Ambient [4] = { 0.1, 0.1, 0.1, 0.1};
GLfloat light_Diffuse [4] = { 1, 1,1, 0.5};
GLfloat light_Position [4] = {-50.0, 10.0, 60.0, 5.0};
//definicion de los materailes
GLfloat GreenMaterial [4] = {0.0, 1.0, 0.0, 0.0 };//verde
GLfloat RedMaterial [4] = {1.0, 0.0, 0.0, 0.0 };//rojo
GLfloat BlueMaterial [4] = {0.0, 0.0, 1.0, 0.0 };//azul
GLfloat OrangeMaterial [4] = {1.000, 0.647, 0.000 };//anaranjado
GLfloat whiteMaterial[4]={1,1,1};//blanco


void luces(void){
        glEnable (GL_LIGHTING);
        glEnable (GL_LIGHT0);
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_Ambient );
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_Diffuse );
        glLightfv(GL_LIGHT0, GL_POSITION, light_Position );

}

void material(GLfloat a1,GLfloat a2,GLfloat a3, GLfloat b1, GLfloat b2,GLfloat b3,GLfloat c1,GLfloat c2,GLfloat c3, GLfloat d){
  GLfloat mat_ambient[]    = {a1,a2,a3};
  GLfloat mat_diffuse[]    = {b1,b2,b3};
  GLfloat mat_specular[]   = {c1,c2,c3};
  GLfloat high_shininess[] = { d};
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,mat_diffuse );
    glMaterialfv(GL_FRONT, GL_SPECULAR,mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

}
//La pelota
void tierra(){

        glNewList(bola,GL_COMPILE);//creamos una lista de visualización
        glPushMatrix();
        // y con un color solido de relleno.
       glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        //textura
        glShadeModel(GL_SMOOTH);//suaviza los bordes
        texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "tierra2.bmp",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
      glEnable(GL_TEXTURE_2D);//activamos la textura
       //usamos la autogeneración de coordenadas
       GLfloat plano_s[4] = {1, 0, 0, 0}; // s=x
       GLfloat plano_t[4] = {0, 1, 0, 0}; // t=y

       //controlar la generación de coordenadas de textura
       glTexGeni (GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
       glTexGenfv (GL_S, GL_OBJECT_PLANE, plano_s);
       glEnable (GL_TEXTURE_GEN_S);
       glTexGeni (GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
       glTexGenfv (GL_T, GL_OBJECT_PLANE, plano_t);
       //---------------------- activamos la texturas
       glEnable(GL_TEXTURE_2D);//activa la textura
       glEnable (GL_TEXTURE_GEN_T);//habilita la generación de texturas en y
       glutSolidSphere(5.0f,70,70);//esfera
       glDisable(GL_TEXTURE_2D);//desactivamos la textura
       glDisable(GL_TEXTURE_GEN_T);//deshabilitamos la generación de texturas
       //-------------------- desactivamos
       glPopMatrix();
       glFlush();
       glEndList();//se completa la lista
       glutSwapBuffers();
}
void mundos(){
  glNewList(mundo,GL_COMPILE);//crear una lista de visualización
  glPushMatrix();
  glShadeModel(GL_SMOOTH);//suaviza los bordes
  glutSolidSphere(3.0f,70,70);//dibujar esfera
  glPopMatrix();
  glEndList(); //se completa la lista
  glutSwapBuffers();
}

void RenderScene(void){
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
        glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
        //AJUSTANDO LA CÁMARA
        glLoadIdentity( );
        glTranslatef(-0.5f,0.0f,-5.0f);
        //EJES DE REFERENCIA
        glLineWidth(5);
        glCallList(1);
        glPushMatrix();
        glScalef(escala,escala,escala);
        //tierra
        glPushMatrix();
        glTranslatef(0,0,5);
        glRotatef(5,1.0f,0.0f,0.0f);
        glRotatef(5,0.0f,1.0f,0.0f);
        glCallList(bola);
        glPopMatrix();
        glPushMatrix();
        //bola1 verde
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, GreenMaterial );
        glPushMatrix();
        glTranslatef(5,3,0.0f);
        glCallList(mundo);
        glPopMatrix();
        glPushMatrix();
        //bola2 azul
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, BlueMaterial );
        glPushMatrix();
        glTranslatef(-5,3,0.0f);
        glCallList(mundo);
        glPopMatrix();
        glPushMatrix();
        //bola3 roja
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, RedMaterial );
        glPushMatrix();
        glTranslatef(8,-6,0.0f);
        glCallList(mundo);
        glPopMatrix();
        //bola4 anaranjado
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, OrangeMaterial );
        glPushMatrix();
        glTranslatef(-3,-6,0.0f);
        glCallList(mundo);
        glPopMatrix();
        glutSwapBuffers();
}

int main(int a, char *b[]){
        glutInit(&a,b);
        glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
        glutInitWindowSize(ResX,ResY);
        glutInitWindowPosition(100,100);
        glutCreateWindow("MUNDOS");
        glutDisplayFunc(RenderScene);
        //OPENGL
        glViewport( 0, 0, ResX, ResY );
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity( );
        glFrustum(-(float)ResX/ResY, (float)ResX/ResY, -1.0, 1.0, 2, 10000.0);
        glMatrixMode( GL_MODELVIEW );
        glLoadIdentity( );
        glEnable(GL_DEPTH_TEST);//activar el GL_DEPTH_TEST
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_TEXTURE_2D);
        glDepthFunc(GL_LEQUAL);
        glShadeModel(GL_SMOOTH);
        glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
        glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
        glClearDepth(1.0f);
        luces();//funcion luces
        tierra();//funcion tierra
        mundos();//funcion mundos
        glutMainLoop();
        return 0;
}
