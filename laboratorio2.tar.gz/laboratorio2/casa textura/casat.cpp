#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>

//Definimos variables
double rotate_y=0;
double rotate_x=0;
double rotate_z=0;

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;

GLint ancho = 800;
GLint alto = 600;

GLuint texture[0];



GLfloat LightAmbient[]={ 0.5f, 0.5f, 0.5f, 1.0f };
GLfloat LightDiffuse[]={ 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat LightPosition[]={ 1.0f, 1.0f, 1.0f, 0.0f };

void init(void)
{
								//Carga la textura
								glEnable(GL_TEXTURE_2D);
								glShadeModel(GL_SMOOTH);
								glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
								glClearDepth(1.0f);
								glEnable(GL_DEPTH_TEST);
								glDepthFunc(GL_LEQUAL);
								glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);


								glDepthFunc(GL_LESS);
								glEnable(GL_DEPTH_TEST);
								glLightfv(GL_LIGHT0, GL_AMBIENT, LightAmbient);
								glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
								glLightfv(GL_LIGHT0,GL_POSITION,LightPosition);
								glLightfv(GL_LIGHT0, GL_DIFFUSE, LightDiffuse);

								glEnable(GL_LIGHT0);

}

void display()
{
								glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

								glMatrixMode(GL_MODELVIEW);
								glLoadIdentity();
								gluLookAt (4, 0.5, -2, 0, 0, 0, 0.0,1.0,0.0);


								glRotatef( rotate_x, 1.0, 0.0, 0.0 );
								glRotatef( rotate_y, 0.0, 1.0, 0.0 );
								glRotatef( rotate_z, 0.0, 0.0, 1.0 );
								glTranslatef(X, Y, Z);

								glScalef(scale, scale, scale);


								texture[0] = SOIL_load_OGL_texture
																					(
																"ladrillo.jpg",
																SOIL_LOAD_AUTO,
																SOIL_CREATE_NEW_ID,
																SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
																					);
								texture[1] = SOIL_load_OGL_texture
																					(
																"techo.jpg",
																SOIL_LOAD_AUTO,
																SOIL_CREATE_NEW_ID,
																SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
																					);
								texture[2] = SOIL_load_OGL_texture
																					(
																"puerta.png",
																SOIL_LOAD_AUTO,
																SOIL_CREATE_NEW_ID,
																SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
																					);
								texture[3] = SOIL_load_OGL_texture
																					(
																"porton.jpg",
																SOIL_LOAD_AUTO,
																SOIL_CREATE_NEW_ID,
																SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
																																		);
								texture[4] = SOIL_load_OGL_texture
																					(
																"ventana.jpeg",
																SOIL_LOAD_AUTO,
																SOIL_CREATE_NEW_ID,
																SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
																																		);



								// Frente de la casa
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f); glVertex3f(3.0f,-6.0f,0.0f);
								glTexCoord2f(1.0f, 0.0f); glVertex3f(3.0f,-6.0f,-1.2f);
								glTexCoord2f(1.0f, 1.0f); glVertex3f(3.0f,-2.0f,-1.2F);
								glTexCoord2f(0.0f, 1.0f); glVertex3f(3.0f,-2.0f,0.0f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-6.0f,-3.4f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-6.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,-2.0f,-4.5F);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,-2.0f,-3.4f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-3.0f,0.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,-2.0f,0.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,-2.0f,-4.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-3.0f,-4.5f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(2.95f,-2.0f,0.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(2.95f,-0.87f,0.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(2.95f,-0.87f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(2.95f,-2.0f,-4.5f);
								glEnd();


								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.05f,-2.5f,-1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.05f,2.0f,-1.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.05f,2.0f,7.2f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.05f,-2.5f,7.2f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-2.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,2.0f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,2.0f,-3.33f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-2.0f,-3.33f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,1.52f,0.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,2.0f,0.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,2.0f,-4.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,1.52f,-4.5f);
								glEnd();

								//Division
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.5f,-6.0f,0.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(-9.5f,-6.0f,0.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,-2.5f,0.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.5f,-2.5f,0.0f);
								glEnd();

								//Cara de las ventanas
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.05f,-6.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.05f,-6.0f,-7.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.05f,-2.0f,-7.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.05f,-2.0f,-4.5f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.05f,-6.0f,-13.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.05f,-6.0f,-10.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.05f,-2.0f,-10.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.05f,-2.0f,-13.5f);
								glEnd();


								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-3.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,-2.0f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,-2.0f,-13.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-3.0f,-13.0f);
								glEnd();


								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-6.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,-5.00f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,-5.0f,-13.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-6.0f,-13.0f);
								glEnd();

								//Cara superior

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.05f,-2.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.05f,-2.0f,-7.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.05f,2.0f,-7.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.05f,2.0f,-4.5f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.05f,-2.0f,-13.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.05f,-2.0f,-10.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.05f,2.0f,-10.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.05f,2.0f,-13.5f);
								glEnd();




								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,1.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,2.0f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,2.0f,-13.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,1.0f,-13.0f);
								glEnd();


								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-2.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,-1.00f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,-1.0f,-13.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-2.0f,-13.0f);
								glEnd();

								//Cara superior lateral izquierdo
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-2.5f,7.2f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(-9.5f,-2.5f,7.2f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,2.0f,7.2F);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,2.0f,7.2f);
								glEnd();

								//Parte lateral derecho
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-6.0f,-13.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(-9.5f,-6.0f,-13.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,2.0f,-13.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,2.0f,-13.5);
								glEnd();

								//Parte trasera
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-9.5f,-6.0f,-13.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(-9.5f,-6.0f,7.21f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,2.0f,7.21f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-9.5f,2.0f,-13.5f);
								glEnd();

								//Techo trasero
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[1]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-9.5f,2.0f,7.2f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(-9.5f,2.0f,-13.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-4.125f,5.1f,-13.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-4.125f,5.1f,7.2f);
								glEnd();

								//Techo frontal
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[1]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,2.0f,7.2f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,2.0f,-13.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-4.125f,5.1f,-13.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-4.125f,5.1f,7.2f);
								glEnd();

								//CARA DE TECHO izquierda
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,2.0f,7.2f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-4.125f,5.1f,7.2f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,2.0f,7.2f);
								glEnd();

								//CARA DE TECHO derecha
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,2.0f,-13.5f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-4.125f,5.1f,-13.5f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,2.0f,-13.5f);
								glEnd();

								//PUERTA
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[2]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.0f,-6.0f,-1.2f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,-3.0f,-1.2f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,-3.0f,-3.4f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.0f,-6.0f,-3.4f);
								glEnd();


								//Cara de techo lateral
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[1]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,2.0f,-4.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,2.0f,-4.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,4.2f,-9.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-4.125f,4.2f,-9.0f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[1]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,2.0f,-13.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.0f,2.0f,-13.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.0f,4.2f,-9.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-4.125f,4.2f,-9.0f);
								glEnd();
							//CARA DE TECHO DELANTERA

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(2.999f,1.9999f,-4.50001f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(2.999f,4.2f,-9.001f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(2.999f,1.9999f,-13.5001f);
								glEnd();

								//COCHERA PAREDES

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-4.4f,-2.5f,7.21f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-4.4f,-6.0f,7.21f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(-9.5f,-6.0f,7.21f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(-9.5f,-2.5f,7.21f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-2.95f,-2.5f,7.21f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-2.95f,-6.0f,7.21f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.5f,-6.0f,7.21f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.5f,-2.5f,7.21f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(-9.5f,-4.5f,7.2f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(-9.5f,-6.0f,7.2f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.5f,-6.0f,7.2f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.5f,-4.5f,7.2f);
								glEnd();

								//Porton
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[3]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.5f,-2.5f,0.7f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.5f,-6.0f,0.7f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.5f,-6.0f,6.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.5f,-2.5f,6.5f);
								glEnd();

								//laterales cochera
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.5f,-6.0f,0.7f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.5f,-2.5f,0.7f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.5f,-2.5f,0.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.5f,-6.0f,0.0f);
								glEnd();

								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[0]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.5f,-6.0f,7.2f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.5f,-2.5f,7.2f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.5f,-2.5f,6.5f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.5f,-6.0f,6.5f);
								glEnd();

								//Techo porton
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[1]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);;
								glVertex3f(3.0f,-2.0f,-4.5f);
								glVertex3f(4.0f,-2.75f,-4.5f);
								glVertex3f(4.0f,-2.75f,7.2f);
								glVertex3f(3.0f,-2.0f,7.2f);
								glEnd();

								//Aplicacion ventana
								//Ventana arriba de puerta
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[4]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.1f,-1.0f,-1.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.1f,1.5f,-1.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.1f,1.5f,-3.3f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.1f,-1.0f,-3.3f);
								glEnd();

								//Ventana arriba derecha
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[4]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.1f,-1.0f,-7.5f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.1f,1.5f,-7.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.1f,1.5f,-10.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.1f,-1.0f,-10.0f);
								glEnd();

								//Ventana abajo derecha
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[4]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.1f,-3.0f,-7.5f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.1f,-5.0f,-7.5f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.1f,-5.0f,-10.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.1f,-3.0f,-10.0f);
								glEnd();

								//Ventana arriba izquierda
								glEnable(GL_TEXTURE_2D);
								glBindTexture(GL_TEXTURE_2D, texture[4]);
								glBegin(GL_POLYGON);
								glNormal3f( 0.0f, 0.0f, 1.0f);
								glTexCoord2f(0.0f, 1.0f);glVertex3f(3.1f,-1.0f,2.0f);
								glTexCoord2f(0.0f, 0.0f);glVertex3f(3.1f,1.5f,2.0f);
								glTexCoord2f(1.0f, 0.0f);glVertex3f(3.1f,1.5f,5.0f);
								glTexCoord2f(1.0f, 1.0f);glVertex3f(3.1f,-1.0f,5.0f);
								glEnd();

								glDisable(GL_TEXTURE_2D);
								//glFlush();
								glutSwapBuffers();

}


void specialKeys( int key, int x, int y )
{

								//derecha
								if (key == GLUT_KEY_RIGHT)
																rotate_y += 7;

								//izquierda
								else if (key == GLUT_KEY_LEFT)
																rotate_y -= 7;
								//arriba
								else if (key == GLUT_KEY_UP)
																rotate_x += 7;
								//abajo
								else if (key == GLUT_KEY_DOWN)
																rotate_x -= 7;
								//  Tecla especial F2 : rotación en eje Z positivo 7 grados
								else if (key == GLUT_KEY_F2)
																rotate_z += 7;
								//  Tecla especial F2 : rotación en eje Z negativo 7 grados
								else if (key == GLUT_KEY_F2)
																rotate_z -= 7;

								//  Solicitar actualización de visualización
								glutPostRedisplay();

}


void reshape (int w, int h)
{
	glViewport(0, 0,(GLsizei) w,(GLsizei) h);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 glOrtho(-20 ,20,-20,20,-40,40);
 glMatrixMode(GL_MODELVIEW);

 ancho = w;
 alto = h;


}

// controlar teclas normales
void keyboard(unsigned char key, int x, int y)
{
								//control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
								switch (key)
								{
								case 's':
																scale +=0.5;
																break;
								case 'd':
																scale-=1.5;
																break;
								case 'x':
																X += 0.1f;
																break;
								case 'X':
																X -= 0.1f;
																break;
								case 'y':
																Y += 0.1f;
																break;
								case 'Y':
																Y -= 0.1f;
																break;
								case 'z':
																Z -= 0.1f;
																break;
								case 'Z':
																Z += 0.1f;
																break;
								case 'q':
																exit(0); // exit
								}
								glutPostRedisplay();
}




int main(int argc, char* argv[])
{

								//  Inicializar los parámetros GLUT y de usuario proceso
								glutInit(&argc,argv);
								// Solicitar ventana con color real y doble buffer con Z-buffer
								glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
								glutInitWindowSize (800, 600);
								glutInitWindowPosition (0, 0);
								// Crear ventana
								glutCreateWindow("casa con texturas");
								init();
								// Habilitar la prueba de profundidad de Z-buffer
								glEnable(GL_DEPTH_TEST);
								// Funciones de retrollamada
								glutDisplayFunc(display);
								glutReshapeFunc(reshape);
								glutKeyboardFunc(keyboard);
								glutSpecialFunc(specialKeys);
								// Pasar el control de eventos a GLUT
								glutMainLoop();
								// Regresar al sistema operativo
								return 0;

}
