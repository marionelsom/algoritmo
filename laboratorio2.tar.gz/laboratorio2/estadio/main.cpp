#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>
#include <math.h>
#include "SOIL.h"

GLuint texture[0];//la textura

//Definimos variables
double rotate_y=-48;
double rotate_x=28;
double rotate_z=0;
GLfloat scale = 1.0f;

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLint ancho=800;
GLint alto=600;

//Definición del modelo de una luz
GLfloat light_Ambient [4] = { 2.0, 2.0, 2.0, 2.0};
GLfloat light_Diffuse [4] = { 10.0, 1.0, 1.0, 1.0};
GLfloat light_Position [4] = {-10.0, 10.0, 0.0, 5.0};

GLfloat GreenMaterial [4] = {0.0, 1.0, 0.0, 0.0 };//verde
GLfloat RedMaterial [4] = {1.0, 0.0, 0.0, 0.0 };//rojo
GLfloat BlueMaterial [4] = {0.0, 0.0, 1.0, 0.0 };//azul
GLfloat OrangeMaterial [4] = {1.000, 0.647, 0.000 };//anaranjado

void luces(void){
        glEnable (GL_LIGHTING);
        glEnable (GL_LIGHT0);
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_Ambient );
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_Diffuse );
        glLightfv(GL_LIGHT0, GL_POSITION, light_Position );

}
void texturaGradas(){
  texture[2] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "gradas.png",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[2]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

}
void texturaPiso(){
  texture[3] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "piso.jpg",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[3]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
}
void texturaPared(){
  texture[4] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "pared.png",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[4]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
}
void texturaPalco(){
  texture[5] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "pal.png",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[5]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
}
void  texturaMuro() {
  texture[1] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "muro.png",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, texture[1]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

}
void material(GLfloat a1,GLfloat a2,GLfloat a3, GLfloat b1, GLfloat b2,GLfloat b3,GLfloat c1,GLfloat c2,GLfloat c3, GLfloat d){
  GLfloat mat_ambient[]    = {a1,a2,a3};
  GLfloat mat_diffuse[]    = {b1,b2,b3};
  GLfloat mat_specular[]   = {c1,c2,c3};
  GLfloat high_shininess[] = { d};
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,mat_diffuse );
    glMaterialfv(GL_FRONT, GL_SPECULAR,mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

}

void cancha(){
  texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "cancha2.jpg",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, texture[0]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

  glBegin(GL_QUADS);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(-15,0,-10);
  glTexCoord2f(1,0);glVertex3f(15,0,-10);
  glTexCoord2f(1,1);glVertex3f(15,0,10);
  glTexCoord2f(0,1);glVertex3f(-15,0,10);
  glEnd();

}
void muros(float px, float py, float pz, float h, float w, float az){
  // puntos en x,y,z, altura, ancho, direcion en z 0 x
  texturaMuro();
  glBegin(GL_QUADS);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(1,0);glVertex3f(px,py,pz);

  glTexCoord2f(1,1);glVertex3f(px,py+h,pz);
  pz +=az;
  if(az==0){
    px +=w;
  }
  glTexCoord2f(0,1);glVertex3f(px,py+h,pz);
  glTexCoord2f(0,0);glVertex3f(px,py,pz);
  glEnd();
}

void pared(float px, float py, float pz, float h, float w, float az){
  texture[1] = SOIL_load_OGL_texture // cargamos la imagen
                     (
      "pared.png",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[1]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

  glBegin(GL_QUADS);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(1,0);glVertex3f(px,py,pz);

  glTexCoord2f(1,1);glVertex3f(px,py+h,pz);
  pz +=az;
  if(az==0){
    px +=w;
  }
  glTexCoord2f(0,1);glVertex3f(px,py+h,pz);
  glTexCoord2f(0,0);glVertex3f(px,py,pz);
  glEnd();
}

void palco(float px, float py, float pz, float h, float w, float az){
  texturaPalco();
  glBegin(GL_QUADS);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(1,0);glVertex3f(px,py,pz);

  glTexCoord2f(1,1);glVertex3f(px,py+h,pz);
  pz +=az;
  if(az==0){
    px +=w;
  }
  glTexCoord2f(0,1);glVertex3f(px,py+h,pz);
  glTexCoord2f(0,0);glVertex3f(px,py,pz);
  glEnd();
}


void gradasEsquinas1(float px, float py, float pz, float h){
  float direcX=0;
  float direcZ=0;
  texturaGradas();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(1,0);glVertex3f(px,py,pz);
  glTexCoord2f(1,1);glVertex3f(px,py+h,pz-4);
  glTexCoord2f(0,1);glVertex3f(px-4,py+h,pz+1);
  glTexCoord2f(0,0);glVertex3f(px,py,pz+1);
  glEnd();
}

void gradasEsquinas2(float px, float py, float pz, float h){
  float direcX=0;
  float direcZ=0;
  texturaGradas();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(1,0);glVertex3f(px,py,pz);
  glTexCoord2f(1,1);glVertex3f(px,py+h,pz-4);
  glTexCoord2f(0,1);glVertex3f(px+4,py+h,pz+1);
  glTexCoord2f(0,0);glVertex3f(px,py,pz+1);
  glEnd();
}
void gradasEsquinas3(float px, float py, float pz, float h){
  float direcX=0;
  float direcZ=0;
  texturaGradas();
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(1,0);glVertex3f(px,py,pz);
    glTexCoord2f(1,1);glVertex3f(px-4,py+h,pz);
    glTexCoord2f(0,1);glVertex3f(px,py+h,pz+5);
    glTexCoord2f(0,0);glVertex3f(px,py,pz+1);
    glEnd();
}
void gradasEsquinas4(float px, float py, float pz, float h){
  float direcX=0;
  float direcZ=0;
  texturaGradas();
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(1,0);glVertex3f(px,py,pz);
    glTexCoord2f(1,1);glVertex3f(px+4,py+h,pz);
    glTexCoord2f(0,1);glVertex3f(px,py+h,pz+5);
    glTexCoord2f(0,0);glVertex3f(px,py,pz+1);
    glEnd();
}
void gradas(float px, float py, float pz, float h, float w, float az, float direc){
  float direcX=0;
  float direcZ=0;
  texturaGradas();
  glBegin(GL_QUADS);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(1,0);glVertex3f(px,py,pz);
  if(az==0){
    direcZ = 1*direc;
  }else{
    direcX =1*direc;
  }
  glTexCoord2f(1,1);glVertex3f(px+direcX,py+h,pz+direcZ);
  pz +=az;

  if(az==0){
    px +=w;
  }
  glTexCoord2f(0,1);glVertex3f(px+direcX,py+h,pz+direcZ);
  glTexCoord2f(0,0);glVertex3f(px,py,pz);
  glEnd();
}

void pisosegunda() {

  texturaPiso();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(-21,2,-10);
  glTexCoord2f(1,0);glVertex3f(-21,2,10);
  glTexCoord2f(1,1);glVertex3f(-19,2,9);
  glTexCoord2f(0,1);glVertex3f(-19,2,-9);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(21,2,-10);
  glTexCoord2f(1,0);glVertex3f(21,2,10);
  glTexCoord2f(1,1);glVertex3f(19,2,9);
  glTexCoord2f(0,1);glVertex3f(19,2,-9);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-15,2,-14);
  glTexCoord2f(1,0);glVertex3f(15,2,-14);
  glTexCoord2f(1,1);glVertex3f(17,2,-16);
  glTexCoord2f(0,1);glVertex3f(-17,2,-16);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-15,2,14);
  glTexCoord2f(1,0);glVertex3f(15,2,14);
  glTexCoord2f(1,1);glVertex3f(17,2,16);
  glTexCoord2f(0,1);glVertex3f(-17,2,16);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-21,2,-10);
  glTexCoord2f(1,0);glVertex3f(-19,2,-9);
  glTexCoord2f(1,1);glVertex3f(-15,2,-14);
  glTexCoord2f(0,1);glVertex3f(-17,2,-16);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-21,2,10);
  glTexCoord2f(1,0);glVertex3f(-19,2,9);
  glTexCoord2f(1,1);glVertex3f(-15,2,14);
  glTexCoord2f(0,1);glVertex3f(-17,2,16);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(21,2,10);
  glTexCoord2f(1,0);glVertex3f(19,2,9);
  glTexCoord2f(1,1);glVertex3f(15,2,14);
  glTexCoord2f(0,1);glVertex3f(17,2,16);
  glEnd();

  texturaPiso();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(21,2,-10);
  glTexCoord2f(1,0);glVertex3f(19,2,-9);
  glTexCoord2f(1,1);glVertex3f(15,2,-14);
  glTexCoord2f(0,1);glVertex3f(17,2,-16);
  glEnd();
}

void paredSegunda(){

  //esquinas superiores
  texturaPared();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-21,2,-10);
  glTexCoord2f(1,0);glVertex3f(-17,2,-16);
  glTexCoord2f(1,1);glVertex3f(-17,3,-16);
  glTexCoord2f(0,1);glVertex3f(-21,3,-10);
  glEnd();

  texturaPared();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(21,2,-10);
  glTexCoord2f(1,0);glVertex3f(17,2,-16);
  glTexCoord2f(1,1);glVertex3f(17,3,-16);
  glTexCoord2f(0,1);glVertex3f(21,3,-10);
  glEnd();

  texturaPared();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(21,2,10);
  glTexCoord2f(1,0);glVertex3f(17,2,16);
  glTexCoord2f(1,1);glVertex3f(17,3,16);
  glTexCoord2f(0,1);glVertex3f(21,3,10);
  glEnd();

  texturaPared();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-21,2,10);
  glTexCoord2f(1,0);glVertex3f(-17,2,16);
  glTexCoord2f(1,1);glVertex3f(-17,3,16);
  glTexCoord2f(0,1);glVertex3f(-21,3,10);
  glEnd();
}

void palcoEsquinas() {
    texturaMuro();
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0,0);glVertex3f(-21,3,-10);
    glTexCoord2f(1,0);glVertex3f(-17,3,-16);
    glTexCoord2f(1,1);glVertex3f(-17,3.3,-16);
    glTexCoord2f(0,1);glVertex3f(-21,3.3,-10);
    glEnd();

  texturaPalco();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-21,3.3,-10);
  glTexCoord2f(1,0);glVertex3f(-17,3.3,-16);
  glTexCoord2f(1,1);glVertex3f(-17,4.3,-16);
  glTexCoord2f(0,1);glVertex3f(-21,4.3,-10);
  glEnd();

  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(-21,4.3,-10);
  glTexCoord2f(1,0);glVertex3f(-17,4.3,-16);
  glTexCoord2f(1,1);glVertex3f(-17,4.6,-16);
  glTexCoord2f(0,1);glVertex3f(-21,4.6,-10);
  glEnd();

  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(21,3,-10);
  glTexCoord2f(1,0);glVertex3f(17,3,-16);
  glTexCoord2f(1,1);glVertex3f(17,3.3,-16);
  glTexCoord2f(0,1);glVertex3f(21,3.3,-10);
  glEnd();

  texturaPalco();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(21,3.3,-10);
  glTexCoord2f(1,0);glVertex3f(17,3.3,-16);
  glTexCoord2f(1,1);glVertex3f(17,4.3,-16);
  glTexCoord2f(0,1);glVertex3f(21,4.3,-10);
  glEnd();

  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(21,4.3,-10);
  glTexCoord2f(1,0);glVertex3f(17,4.3,-16);
  glTexCoord2f(1,1);glVertex3f(17,4.6,-16);
  glTexCoord2f(0,1);glVertex3f(21,4.6,-10);
  glEnd();


  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(21,3,10);
  glTexCoord2f(1,0);glVertex3f(17,3,16);
  glTexCoord2f(1,1);glVertex3f(17,3.3,16);
  glTexCoord2f(0,1);glVertex3f(21,3.3,10);
  glEnd();

  texturaPalco();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(21,3.3,10);
  glTexCoord2f(1,0);glVertex3f(17,3.3,16);
  glTexCoord2f(1,1);glVertex3f(17,4.3,16);
  glTexCoord2f(0,1);glVertex3f(21,4.3,10);
  glEnd();

  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(21,4.3,10);
  glTexCoord2f(1,0);glVertex3f(17,4.3,16);
  glTexCoord2f(1,1);glVertex3f(17,4.6,16);
  glTexCoord2f(0,1);glVertex3f(21,4.6,10);
  glEnd();


  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(-21,3,10);
  glTexCoord2f(1,0);glVertex3f(-17,3,16);
  glTexCoord2f(1,1);glVertex3f(-17,3.3,16);
  glTexCoord2f(0,1);glVertex3f(-21,3.3,10);
  glEnd();

  texturaPalco();
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);glVertex3f(-21,3.3,10);
  glTexCoord2f(1,0);glVertex3f(-17,3.3,16);
  glTexCoord2f(1,1);glVertex3f(-17,4.3,16);
  glTexCoord2f(0,1);glVertex3f(-21,4.3,10);
  glEnd();

  texturaMuro();
  glBegin(GL_POLYGON);
  glNormal3f( 0.0f, 0.0f, 1.0f);
  glTexCoord2f(0,0);glVertex3f(-21,4.3,10);
  glTexCoord2f(1,0);glVertex3f(-17,4.3,16);
  glTexCoord2f(1,1);glVertex3f(-17,4.6,16);
  glTexCoord2f(0,1);glVertex3f(-21,4.6,10);
  glEnd();


}

void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w,(GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    // glFrustum (-1.0, 1.0, -1.0, 1.0, 0.5, 100.0);
    glMatrixMode(GL_MODELVIEW);


}


void display()
{
    glClearColor(0.2,0.2,0.4,0.0);
    //  Borrar pantalla y Z-buffer
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	  glColor3f(1.0,0.0,1.0);
    // Resetear transformaciones
    glLoadIdentity();
    luces();
    // gluLookAt(0.0, 0.0, 5.0, //eye (x,y,z)
    //  0.0, 0.0, 0.0,           //at(x,y,z)
    //  0.0, 1.0, 0.0);          //up (x,y,z)

    //glTranslatef(0.0f, 0.0f, -0.2f);
    glTranslatef(X, Y, Z); 	// Transladar en los 3 ejes

	glOrtho(-20,20,-20, 20, -20, 20);

  glRotatef( rotate_x, 1.0, 0.0, 0.0 );
 glRotatef( rotate_y, 0.0, 1.0, 0.0 );
 glRotatef( rotate_z, 0.0, 0.0, 1.0 );
    glScalef(1.0, 2.0, 1.0);
// drawSphere(30,30,1);


    cancha();
    glFlush();
    muros(-15,0,-10,0.5,5,0);
    muros(-10,0,-10,0.5,5,0);
    muros(-5,0,-10,0.5,5,0);
    muros(0,0,-10,0.5,5,0);
    muros(5,0,-10,0.5,5,0);
    muros(10,0,-10,0.5,5,0);

    muros(-15,0,10,0.5,5,0);
    muros(-10,0,10,0.5,5,0);
    muros(-5,0,10,0.5,5,0);
    muros(0,0,10,0.5,5,0);
    muros(5,0,10,0.5,5,0);
    muros(10,0,10,0.5,5,0);

    // muros esquinas pequenias
    muros(-15,0,-10,0.5,0.2,1);
    muros(-15,0,9,0.5,0.2,1);
    muros(15,0,9,0.5,0.2,1);
    muros(15,0,-10,0.5,0.2,1);
    //
    muros(15,0,-7,0.5,0.2,3.5);
    muros(15,0,-3.5,0.5,0.2,3.5);
    muros(15,0,0,0.5,0.2,3.5);
    muros(15,0,3.5,0.5,0.2,3.5);

    muros(-15,0,-7,0.5,0.2,3.5);
    muros(-15,0,-3.5,0.5,0.2,3.5);
    muros(-15,0,0,0.5,0.2,3.5);
    muros(-15,0,3.5,0.5,0.2,3.5);

    gradas(-15,0,-10,2,5,0,-4);
    gradas(-10,0,-10,2,5,0,-4);
    gradas(-5,0,-10,2,5,0,-4);
    gradas(0,0,-10,2,5,0,-4);
    gradas(5,0,-10,2,5,0,-4);
    gradas(10,0,-10,2,5,0,-4);


    gradas(-15,0,10,2,5,0,4);
    gradas(-10,0,10,2,5,0,4);
    gradas(-5,0,10,2,5,0,4);
    gradas(0,0,10,2,5,0,4);
    gradas(5,0,10,2,5,0,4);
    gradas(10,0,10,2,5,0,4);

    gradas(15,0,-7,2,0.2,3.5,4);
    gradas(15,0,-3.5,2,0.2,3.5,4);
    gradas(15,0,0,2,0.2,3.5,4);
    gradas(15,0,3.5,2,0.2,3.5,4);

    gradas(-15,0,-7,2,0.2,3.5,-4);
    gradas(-17,1,-9,1,0.2,2,-2);
    muros(-17,1,-9,0.2,0.2,2);

    gradas(17,1,-9,1,0.2,2,2);
    muros(17,1,-9,0.2,0.2,2);


    gradas(-17,1,7,1,0.2,2,-2);
    muros(-17,1,9,0.2,0.2,-2);

    gradas(17,1,7,1,0.2,2,2);
    muros(17,1,9,0.2,0.2,-2);


    gradas(-15,0,-3.5,2,0.2,3.5,-4);
    gradas(-15,0,0,2,0.2,3.5,-4);
    gradas(-15,0,3.5,2,0.2,3.5,-4);

    gradasEsquinas1(-15,0,-10,2);
    gradasEsquinas2(15,0,-10,2);
    gradasEsquinas3(-15,0,9,2);
    gradasEsquinas4(15,0,9,2);

    pisosegunda();
    paredSegunda();

    pared(-17,2,-16,1,9,0);
    pared(-8,2,-16,1,9,0);
    pared(1,2,-16,1,9,0);
    pared(10,2,-16,1,7,0);

    pared(-17,2,16,1,9,0);
    pared(-8,2,16,1,9,0);
    pared(1,2,16,1,9,0);
    pared(10,2,16,1,7,0);

    pared(-21,2,-10,1,9,7);
    pared(-21,2,-3,1,9,7);
    pared(-21,2,4,1,9,6);

    pared(21,2,-10,1,9,7);
    pared(21,2,-3,1,9,7);
    pared(21,2,4,1,9,6);

    palco(-17,3.3,-16,1,9,0);
    palco(-8,3.3,-16,1,9,0);
    palco(1,3.3,-16,1,9,0);
    palco(10,3.3,-16,1,7,0);

    muros(-17,3,-16,0.3,5,0);
    muros(-12,3,-16,0.3,5,0);
    muros(-7,3,-16,0.3,5,0);
    muros(-2,3,-16,0.3,5,0);
    muros(3,3,-16,0.3,5,0);
    muros(8,3,-16,0.3,5,0);
    muros(13,3,-16,0.3,4,0);

    palco(-17,3.3,16,1,9,0);
    palco(-8,3.3,16,1,9,0);
    palco(1,3.3,16,1,9,0);
    palco(10,3.3,16,1,7,0);

    muros(-17,3,16,0.3,5,0);
    muros(-12,3,16,0.3,5,0);
    muros(-7,3,16,0.3,5,0);
    muros(-2,3,16,0.3,5,0);
    muros(3,3,16,0.3,5,0);
    muros(8,3,16,0.3,5,0);
    muros(13,3,16,0.3,4,0);

    muros(-21,3,-10,0.3,9,7);
    muros(-21,3,-3,0.3,9,7);
    muros(-21,3,4,0.3,9,6);

    palco(-21,3.3,-10,1,9,7);
    palco(-21,3.3,-3,1,9,7);
    palco(-21,3.3,4,1,9,6);

    muros(21,3,-10,0.3,9,7);
    muros(21,3,-3,0.3,9,7);
    muros(21,3,4,0.3,9,6);

    palco(21,3.3,-10,1,9,7);
    palco(21,3.3,-3,1,9,7);
    palco(21,3.3,4,1,9,6);

    palcoEsquinas();



    glutSwapBuffers();

}

void init()
{
    glClearColor(0,0,0,0);
    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);

}

// Función para controlar teclas especiales
void specialKeys( int key, int x, int y )
{

    //  Flecha derecha: aumentar rotación 7 grados
    if (key == GLUT_KEY_RIGHT)
        rotate_y += 7;

    //  Flecha izquierda: rotación en eje Y negativo 7 grados
    else if (key == GLUT_KEY_LEFT)
        rotate_y -= 7;
    //  Flecha arriba: rotación en eje X positivo 7 grados
    else if (key == GLUT_KEY_UP)
        rotate_x += 7;
    //  Flecha abajo: rotación en eje X negativo 7 grados
    else if (key == GLUT_KEY_DOWN)
        rotate_x -= 7;
    //  Tecla especial F2 : rotación en eje Z positivo 7 grados
    else if (key == GLUT_KEY_F2)
        rotate_z += 7;
    //  Tecla especial F2 : rotación en eje Z negativo 7 grados
    else if (key == GLUT_KEY_F2)
        rotate_z -= 7;

    //  Solicitar actualización de visualización
    glutPostRedisplay();

}

//~ // Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
    switch (key)
    {
    case 's':
        scale=0.5;
        break;
    case 'd':
        scale=1.5;
        break;
    case 'x' :
        X += 0.1f;
        break;
    case 'X' :
        X -= 0.1f;
        break;
    case 'y' :
        Y += 0.1f;
        break;
    case 'Y' :
        Y -= 0.1f;
        break;
    case 'z':
        Z -= 0.1f;
        break;
    case 'Z':
        Z += 0.1f;
        break;
    case 27:
        exit(0);			// exit
    }
    glutPostRedisplay();
}



int main(int argc, char* argv[])
{

    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);

    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 600);

    // Crear ventana
    glutCreateWindow("cancha");
	init();
    // Funciones de retrollamada
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity( );
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
      glEnable(GL_TEXTURE_2D);
      glDepthFunc(GL_LEQUAL);
    glShadeModel(GL_SMOOTH);
  glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

    // Pasar el control de eventos a GLUT
    glutMainLoop();

    // Regresar al sistema operativo
    return 0;

}
