/*Creado por Mario Nelson Torres Mena*/
/*Fecha 29 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

float limites = 10.0;
void Engranajes(GLfloat xp1, GLfloat yp1, float r, float g, float b, float h){
  glColor3f(r,g,b);
  glPointSize(4.0f);
  glBegin(GL_POLYGON);
  GLfloat cx=xp1;
  GLfloat cy=yp1;
  GLfloat angulo;
  int j=0; //0 entra, 1 sale
  for (GLfloat i=0; i<360; i+=1){
        if(h<=10 && j==0){
          //dibuja circulo grande
          glVertex2f(cx,cy);
          angulo= i*M_PI/140;
          cx=2.5*cos(angulo)+xp1;
          cy=2.5*sin(angulo)+yp1;
          glVertex2f(cx,cy);
          if(h==10){
            h=0;
            j=1;
          }
        }
        if(h<=10 && j==1){
          //dibuja circulo pequeño
          glVertex2f(cx,cy);
          angulo= i*M_PI/140;
          cx=2*cos(angulo)+xp1;
          cy=2*sin(angulo)+yp1;
          glVertex2f(cx,cy);
          if(h==10){
            h=0;
            j=0;
          }
        }
h+=0.5;
  }
   glEnd();
   glColor3f(0.1,1.0,0.5);
   glPointSize(4.0f);
   glBegin(GL_POLYGON);
   cx=0;
   cy=0;
   for (GLfloat i=0; i<360; i+=0.1){
         glColor3f(0.2,0.2,0.2);
         angulo= i*M_PI/180.0f;
         cx=1.2*cos(angulo)+xp1;
         cy=1.2*sin(angulo)+yp1;
         glVertex2f(cx,cy);
   }
    glEnd();
}
void display(void)
{
	glClearColor(0.2,0.2,0.2,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    Engranajes(0.0,0.0, 0.2, 0.6, 0.4, 1);// puntos(x,y), color(rgb), rotacion de 0 a 10
    Engranajes(-4.4,-2.3, 0.0, 0.0, 0.0, -1); // puntos(x,y), color(rgb), rotacion de 0 a 10
    Engranajes(4.8,-1.3, 0.5, 0.5, 0.5,-3);// puntos(x,y), color(rgb), rotacion de 0 a 10
    glFlush();
}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(limites), (limites), -(limites), (limites), -(limites),(limites));
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 420);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("engranajes");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
