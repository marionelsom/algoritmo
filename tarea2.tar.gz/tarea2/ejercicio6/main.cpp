/*Creado por Mario Nelson Torres Mena*/
/*Fecha 29 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

float limites = 10.0;
void Lineas(GLfloat xp1, GLfloat yp1, GLfloat xp2, GLfloat yp2, GLfloat r, GLfloat g, GLfloat b) {
  //recibe los dos puntos (x,y,z) (x,y,z) y color rgb
  glBegin(GL_LINES);
  glColor3f(r,g,b);
  glVertex2f(xp1,yp1);
  glVertex2f(xp2,yp2);
  glEnd();
}
void Puntos(GLfloat xp1, GLfloat yp1, GLfloat r, GLfloat g, GLfloat b) {
  //recibe puntos (x,y,z) (x,y,z)
  glBegin(GL_POINTS);
  glColor3f(r,g,b);
  glVertex2f(xp1,yp1);
  glEnd();
}
void Lineas_inclinadas(float x, float y, float d, float angulo){

  float cx=0;
  float cy=0;
  float a;
  for (GLfloat i=0; i<=angulo; i+=0.01){
        a= i*M_PI/180.0f;
        cx=d*cos(a)+x;
        cy=d*sin(a)+y;
        //Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  }
  Lineas(x,y,cx, cy, 0.1,0.0,0.2);

}
void cuadros(float x, float y, float h, float w, float angulo){
  Lineas(x,y,x,y+h, 0.1,0.0,0.2);

  float cx=0;
  float cy=0;
  float a;
  for (GLfloat i=0; i<angulo; i+=0.01){
        a= i*M_PI/180.0f;
        cx=w*cos(a)+x;
        cy=w*sin(a)+y;
        //Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  }
  Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  Lineas(x,y+h,cx, cy+h, 0.1,0.0,0.2);
  Lineas(cx, cy+h,cx, cy, 0.1,0.0,0.2);

}
void ventanas(float x, float y, float h, float w, float angulo, float numero){
  //marco 1.0
  Lineas(x,y,x,y+h, 0.1,0.0,0.2);

  float cx=0;
  float cy=0;
  float a;
  for (GLfloat i=0; i<=angulo; i+=0.01){
        a= i*M_PI/180.0f;
        cx=w*cos(a)+x;
        cy=w*sin(a)+y;
  }
  Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  Lineas(x,y+h,cx, cy+h, 0.1,0.0,0.2);
  Lineas(cx, cy+h,cx, cy, 0.1,0.0,0.2);
//marco 1.1
if(angulo<=90){
x+=0.2;
y+=0.3;
w-=0.5;
h-=0.5;}
if(angulo>90 && angulo<=180){
  x-=0.2;
  y+=0.3;
  w-=0.5;
  h-=0.5;
}
Lineas(x,y,x,y+h, 0.1,0.0,0.2);

for (GLfloat i=0; i<angulo; i+=0.01){
      a= i*M_PI/180.0f;
      cx=w*cos(a)+x;
      cy=w*sin(a)+y;
}
Lineas(x,y,cx, cy, 0.1,0.0,0.2);
float cx1=cx,cy1=cy;
Lineas(x,y+h,cx, cy+h, 0.1,0.0,0.2);
Lineas(cx, cy+h,cx, cy, 0.1,0.0,0.2);
//marco 1.2
  y+=0.3;
  w-=0.2;
  h-=0.3;
Lineas(x,y,x,y+h, 0.1,0.0,0.2);
for (GLfloat i=0; i<angulo; i+=0.01){
      a= i*M_PI/180.0f;
      cx=w*cos(a)+x;
      cy=w*sin(a)+y;
}
Lineas(x,y,cx, cy, 0.1,0.0,0.2);
Lineas(cx, cy,cx1,cy1, 0.1,0.0,0.2);
Lineas(cx, cy+h,cx, cy, 0.1,0.0,0.2);
//
//ventanas
float ancho= (w/numero); //ancho del marcho entre numero de ventanas
float nx,ny;
for(float j=1;j<=numero;j++){
  //Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  if(j>1){

  w=ancho;
  y=ny;
  x=nx;
}else{
  y+=0.2;
  w=ancho-0.1;
  h-=0.2;

}
 // Lineas(cx+0.2, cy+h+0.2,cx+0.2, cy+0.2, 0.1,0.0,0.2);
  for (GLfloat i=0; i<angulo; i+=0.01){
        a= i*M_PI/180.0f;
        cx=w*cos(a)+x;
        cy=w*sin(a)+y;
  }

  Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  Lineas(cx, cy+h,cx, cy, 0.1,0.0,0.2);
  nx=cx;
  ny=cy;
}


}
void display(void)
{
	glClearColor(0.2,0.2,0.2,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    //plano
    // Lineas(-(limites),0.0f, (limites),-0.0f, 1.0,0.0,0.0);
    // Lineas(0.0f,(limites),0.0f,-(limites), 0.0,0.0,1.0);

    // ventanas(2,3,5,3,150,1); //punto (x,y) de inicio, alto de marco, ancho de marco, angulo, numero de ventanas
    // cuadros(-6,7,5,5,50,3);
    // Lineas_inclinadas(1,1,3,360);

    //cuadros(-8,-6,4,5,320,3);
    //cochera
    Lineas_inclinadas(-8,-6,3.9,90);
    Lineas_inclinadas(-8,-6,4,320);
    Lineas_inclinadas(-4.95,-8.56,4.1,90);
      //ventana
      ventanas(-5.5,-7,2,1.5,136,1);
      //techo
      Lineas_inclinadas(-8.1,-6+4,3.99,317);
      Lineas_inclinadas(-5.2,-4.7,3,40);
      Lineas_inclinadas(-5.2,-4.7,0.4,90);
      Lineas_inclinadas(-8.1,-6+4,0.4,90);
      Lineas_inclinadas(-8.1,-1.6,3.99,317);
      Lineas_inclinadas(-5.2,-4.3,3,40);
      Lineas_inclinadas(-8.1,-1.6,3,40);
      Lineas_inclinadas(-5.84,0.35,3.99,317);

      Lineas_inclinadas(-2.93,-2.4,1.5,350);
      Lineas_inclinadas(-2.93,-2.77,1.5,350);
      Lineas_inclinadas(-5.84,0.35,5.3,326);
      Lineas_inclinadas(-1.45,-3,0.4,90);
      Lineas_inclinadas(-4.95,-8.56,0.3,15);
      Lineas_inclinadas(-4.65,-8.53,3.5,90);
      Lineas_inclinadas(-4.65,-5.03,3.2,25);



      //porton
        Lineas_inclinadas(-4.65,-5.3,2,300);
        Lineas_inclinadas(-3.66,-7.05,3.1,23);
        Lineas_inclinadas(-2,-3.8,2.4,300);

        //Lineas_inclinadas(-1.45,-6.5,3.5,90);
        Lineas_inclinadas(-1.45,-4.7,1.8,90);
        Lineas_inclinadas(-1.45,-7.15,1,90);

        Lineas_inclinadas(-1.75,-7.2,1,90);
        Lineas_inclinadas(-1.75,-4.2,0.5,90);
        Lineas_inclinadas(-1.85,-4.05,0.3,90);
          Lineas_inclinadas(-1.85,-7.05,0.75,90);
        Lineas_inclinadas(-1.75,-7.2,0.3,15);
        Lineas_inclinadas(-1.75,-7.2,0.2,120);

        //planta baja
        Lineas_inclinadas(-1.45,-7.15,0.9,320);
        Lineas_inclinadas(-0.78,-7.69,10,90);
        Lineas_inclinadas(-0.78,-7.69,0.7,15);

        Lineas_inclinadas(-5.1,-0.2,1.5,90);
        Lineas_inclinadas(-5.1,1.3,5.6,320);
        Lineas_inclinadas(-0.78,-2.3,2.5,15);

        //techo puerta
          Lineas_inclinadas(-0.2,-3,1.6,15);
          Lineas_inclinadas(0.4,-4.0,1.6,15);
          Lineas_inclinadas(0.4,-4.0,1.15,121);
          Lineas_inclinadas(1.9,-3.55,1.15,121);
          Lineas_inclinadas(0.3,-4.0,1,121);
          Lineas_inclinadas(-0.2,-4.0,1,90);
          Lineas_inclinadas(-0.2,-4.0,0.7,0);
          //puerta
          Lineas_inclinadas(-0.1,-7.55,3.55,90);
          Lineas_inclinadas(-0.1,-7.55,0.5,320);
          Lineas_inclinadas(-0.1,-7.4,0.5,320);
          Lineas_inclinadas(0.29,-7.9,0.2,90);
          Lineas_inclinadas(-0.1,-7.4,1.27,15);
          Lineas_inclinadas(1.1,-7.1,0.5,320);
          Lineas_inclinadas(0.3,-7.7,1.22,15);
          Lineas_inclinadas(0.3,-7.9,1.22,15);
          Lineas_inclinadas(1.5,-7.6,0.2,90);

          Lineas_inclinadas(1.6,-3,1.4,90); //PARTE DE LA ENTRADA
          Lineas_inclinadas(1.6,-7.1,3.45,90); //PARTE DE LA ENTRADA
          Lineas_inclinadas(1.25,-7.16,0.4,15);

          Lineas_inclinadas(1.1,-7.1,3.3,90);
          Lineas_inclinadas(1,-7,3.18,90);
          Lineas_inclinadas(-0.1,-7.3,1.15,15);

          cuadros(0.1,-6.99,1.5,0.3,15);
          cuadros(0.56,-6.8,1.5,0.3,15);
          cuadros(0.3,-5,0.2,0.4,15);
          cuadros(0.56,-4.4,0.46,0.3,15);
          // cuadros(0.1,-4.5,0.40,0.3,15);
          Lineas_inclinadas(0.1,-4.5,0.3,15);
          Lineas_inclinadas(0.1,-4.5,0.49,90);
          Lineas_inclinadas(0.4,-4.47,0.49,90);

          Lineas_inclinadas(1.6,-7.1,0.9,320);
          Lineas_inclinadas(1.6,-1.6,0.9,320);
          Lineas_inclinadas(2.3,-7.7,5.55,90);
          Lineas_inclinadas(2.3,-7.7,5,15);
          Lineas_inclinadas(2.3,-2.15,5,15);

          ventanas(3,-6.4,3,3.5,15,3);


        Lineas_inclinadas(7.1,-6.4,5.55,90);
        //segunda planta
        ventanas(-3.5,1,3,1.5,140,2);
        ventanas(-1.5,-0.5,3,1.5,140,2);
        Lineas_inclinadas(-0.78,2.35,2.5,15);
        ventanas(3,-0.5,3,3.5,15,3);
        ventanas(-0.3,-0.5,3,1.5,15,1);

        Lineas_inclinadas(1.6,-1.6,4.6,90);
        Lineas_inclinadas(2.3,-2.15,4.8,90);
        Lineas_inclinadas(1.6,3,0.9,320);
        Lineas_inclinadas(7.1,-0.9,4.5,90);

        Lineas_inclinadas(-5.1,1.3,4.1,90);
        //techo casa
        Lineas_inclinadas(1.6,3.2,0.9,320);
        Lineas_inclinadas(2.3,2.64,4,55);
        Lineas_inclinadas(2.3,2.4,4,55);
        Lineas_inclinadas(7.3,3.4,3.55,140);
        Lineas_inclinadas(7.3,3.67,3.55,140);
        Lineas_inclinadas(7.3,3.4,0.21,180);
        Lineas_inclinadas(7.3,3.4,0.25,90);

        Lineas_inclinadas(1.6,3.2,3,80);
        Lineas_inclinadas(2.12,6.2,2.5,354);

        cuadros(0,6.7,0.8,0.5,15);
        Lineas_inclinadas(0.1,7.95,0.5,320);
        Lineas_inclinadas(-0.4,7.85,0.5,320);
        Lineas_inclinadas(-0.4,7.85,0.5,15);
        Lineas_inclinadas(-0.4,7.85,0.6,270);
        Lineas_inclinadas(0,6.7,0.65,110);
        Lineas_inclinadas(1.6,3.2,2.5,195);

        Lineas_inclinadas(-0.78,2.5,4.5,110);
        Lineas_inclinadas(-0.78,2.3,4.5,110);
        Lineas_inclinadas(4,6,2.35,110);

        Lineas_inclinadas(-5.5,5.57,3.4,20);
        Lineas_inclinadas(-5.5,5.3,3.4,20);
        Lineas_inclinadas(-5.3,5.3,3.25,20);
        Lineas_inclinadas(-5.5,5.3,0.4,358);
        Lineas_inclinadas(-5.5,5.3,0.3,90);


        Lineas_inclinadas(0.5,7.5,2.8,15);
        Lineas_inclinadas(-2.4,6.7,2.3,15);
glFlush();
}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(limites), (limites), -(limites), (limites), -(limites),(limites));
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 400);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("CASA");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
