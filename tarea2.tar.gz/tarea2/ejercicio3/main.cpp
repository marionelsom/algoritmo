/*Creado por Mario Nelson Torres Mena*/
/*Fecha 26 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

float limites = 15.0;

void Lineas(GLfloat xp1, GLfloat yp1, GLfloat xp2, GLfloat yp2, GLfloat r, GLfloat g, GLfloat b) {
  //recibe los dos puntos (x,y,z) (x,y,z) y color rgb
  glBegin(GL_LINES);
  glColor3f(r,g,b);
  glVertex2f(xp1,yp1);
  glVertex2f(xp2,yp2);
  glEnd();
}
void Puntos(GLfloat xp1, GLfloat yp1, GLfloat r, GLfloat g, GLfloat b) {
  //recibe puntos (x,y,z) (x,y,z)
  glBegin(GL_POINTS);
  glColor3f(r,g,b);
  glVertex2f(xp1,yp1);
  glEnd();
}
void display(void)
{
	glClearColor(0.2,0.2,0.2,0.0);
    glClear(GL_COLOR_BUFFER_BIT);

//base
    Lineas(-8,-4.5,8,-7,0.0,0.0,1.0);
    Lineas(-5,-2,10,-4,0.0,0.0,1.0);
    Lineas(-6.5,13.3,9,11,0.0,0.0,1.0);
    Lineas(9,11,8,-7,0.0,0.0,1.0);
    Lineas(9,11,10,-4,0.0,0.0,1.0);

    Lineas(-5,8,-6.5,13.3,0.0,0.0,1.0);
    Lineas(-1,7.6,-2.5,12.7,0.0,0.0,1.0);
    Lineas(-3.5,4.8,-2.5,12.7,0.0,0.0,1.0);
    Lineas(-8,5.5,-6.5,13.3,0.0,0.0,1.0);

    Lineas(-5,-2,-5,8,0.0,0.0,1.0);
    Lineas(-8,-4.5,-8,5.5,0.0,0.0,1.0);

    Lineas(-1,-2.55,-1,7.6,0.0,0.0,1.0);
    Lineas(-3.5,-5.2,-3.5,4.8,0.0,0.0,1.0);

    Lineas(-8,-4.5,-5,-2,0.0,0.0,1.0);
    Lineas(8,-7,10,-4,0.0,0.0,1.0);
    Lineas(-8,0,-3.5,-0.4,0.0,0.0,1.0);

    Lineas(-5,2.5,-8,0,0.0,0.0,1.0);
    Lineas(-5,2.5,-1,1.95,0.0,0.0,1.0);
    Lineas(-1,1.95,-3.5,-0.4,0.0,0.0,1.0);

    //
    Lineas(-5,8,-8,5.5,0.0,0.0,1.0);
    Lineas(-5,8,-1,7.6,0.0,0.0,1.0);
    Lineas(-3.5,4.8,-1,7.6,0.0,0.0,1.0);
    Lineas(-3.5,4.8,-8,5.5,0.0,0.0,1.0);

    //deslizadero
    Lineas(-8,0,-11.5,-6.4,0.0,0.0,1.0);
    Lineas(-3.5,-0.4,-6.8,-7.8,0.0,0.0,1.0);
    Lineas(-11.5,-6.4,-6.8,-7.8,0.0,0.0,1.0);

    //columpios
    Lineas(0,12.35,0,0,0.0,0.0,1.0);
    Lineas(2.5,11.97,2.5,-0.38,0.0,0.0,1.0);

    Lineas(-0.6,-0.6,0.6,0.6,0.0,0.0,1.0);
    Lineas(2.0,-0.98,3.0,0.22,0.0,0.0,1.0);

    Lineas(-0.6,-0.6,2.0,-0.98,0.0,0.0,1.0);
    Lineas(0.6,0.6,3.0,0.22,0.0,0.0,1.0);

    //columpio2
    Lineas(4.5,11.68,4.5,-0.67,0.0,0.0,1.0);//0.29
    Lineas(7,11.35,7,-1.0,0.0,0.0,1.0);//0.62

    Lineas(3.9,-1.58,5.1,0.07,0.0,0.0,1.0);
    Lineas(6.4,-1.9,7.6,0.07,0.0,0.0,1.0);

    Lineas(5.1,0,7.6,0,0.0,0.0,1.0);
    Lineas(3.9,-1.58,6.4,-1.9,0.0,0.0,1.0);

    glFlush();

}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(limites), (limites), -(limites), (limites), -(limites),(limites));
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 420);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Juegos");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
