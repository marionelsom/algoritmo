/*Creado por Mario Nelson Torres Mena*/
/*Fecha 28 de marzo de 2018*/
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

float limites = 10.0;

void Circulos(GLfloat xp1, GLfloat yp1, GLfloat anguloI, GLfloat anguloF){
  //recibe un punto (centro del Circulo) y el angulo que iniciara , y el angulo donde finalizara
  glPointSize(1.0f);
  glBegin(GL_POINTS);
  GLfloat cx=0;
  GLfloat cy=0;
  GLfloat angulo;
  for (GLfloat i=anguloI; i<anguloF; i+=0.01){
    angulo= i;
    cx=cos(angulo)+xp1;
    cy=sin(angulo)+yp1;
    glVertex2f(cx,cy);
  }
   glEnd();
}

void Lineas(GLfloat xp1, GLfloat yp1, GLfloat xp2, GLfloat yp2, GLfloat r, GLfloat g, GLfloat b) {
  //recibe los dos puntos (x,y,z) (x,y,z) y color rgb
  glBegin(GL_LINES);
  glColor3f(r,g,b);
  glVertex2f(xp1,yp1);
  glVertex2f(xp2,yp2);
  glEnd();
}
void Puntos(GLfloat xp1, GLfloat yp1, GLfloat r, GLfloat g, GLfloat b) {
  //recibe puntos (x,y,z) (x,y,z)
  glBegin(GL_POINTS);
  glColor3f(r,g,b);
  glVertex2f(xp1,yp1);
  glEnd();
}
void display(void)
{
	glClearColor(0.2,0.2,0.2,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    //plano
    // Lineas(-(limites),0.0f, (limites),-0.0f, 1.0,0.0,0.0);
    // Lineas(0.0f,(limites),0.0f,-(limites), 0.0,0.0,1.0);

    Lineas(-2.72,4.43, 1.53,8,0.0,1.0,0.0);//a-b
    Lineas(-1.22,4.37, 3.06,8.06,0.0,1.0,0.0);//c-d
    Lineas(-2.72,4.43,-1.22,4.37,0.0,1.0,0.0);//a-c
    Lineas(1.53,8,3.06,8.06,0.0,1.0,0.0);//d-b

    Lineas(-2.72,4.43, -2.7, -5.41, 0.0,1.0,0.0);//a-e
    Lineas(-1.22,4.37, -1.2, -3.6, 0.0,1.0,0.0);//c-f
    Lineas(1.71,-0.05, 1.58, 6.78, 0.0,1.0,0.0);//g-h
    Lineas(-1.2, -3.6, 1.71,-0.05, 0.0,1.0,0.0);//f-g
    Lineas(7.16,-2.02, 1.58, 6.78, 0.0,1.0,0.0);//i-h
    Lineas(7.16,-2.02, 1.71,-0.05, 0.0,1.0,0.0);//i-g
    Lineas(8.08,-0.77, 3.06,8.06,0.0,1.0,0.0);//j-d
    Lineas(-0.62,3.46,-0.61,-0.78,0.0,1.0,0.0);//k-n
    Lineas(-0.62,3.46,1,5,0.0,1.0,0.0);//k-L
    Lineas(1,1,1,5,0.0,1.0,0.0);//m-L
    Lineas(1,1,-0.61,-0.78,0.0,1.0,0.0);//m-n
    Lineas(1,1,0.11,1.38,0.0,1.0,0.0);//m-o
    Lineas(-0.62,0.6,0.11,1.38,0.0,1.0,0.0);//p-o
    Lineas(0.11,4.2,0.11,1.38,0.0,1.0,0.0);//p-o
    Lineas(3.0,-5.3, -1.2, -3.6, 0.0,1.0,0.0);//r-f
    Lineas(8.08,-0.77, 4.9,-4.90,0.0,1.0,0.0);//j-s
    Lineas(8.08,-0.77, 8.08,-3.0,0.0,1.0,0.0);//j-t

    Lineas(8.08,-3.0, 4.5,-7.4,0.0,1.0,0.0);//j-s2
    Lineas(-2.7,-5.41, 3.35, -7.5, 0.0,1.0,0.0);//e-w

    Circulos(3.5,-3.5,0,360);

    float y;
    float xinicio=3.0;
    float yinicio=-5.3;
    for (float x = 0; x<=2; x+=0.001) {
      y = pow(x,2.5);
      y=0.09*y;
      Puntos(xinicio + x,yinicio + y, 0.0,1.0,0.0);
    }

    float xinicio2=3.35;
    float yinicio2=-7.5;
    for (float x = 0; x<=1.3; x+=0.001) {
      y = pow(x,2);
      y=0.09*y;
      Puntos(xinicio2 + x,yinicio2 + y, 0.0,1.0,0.0);
    }

glFlush();

}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(limites-4), (limites), -(limites), (limites), -(limites),(limites));
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 420);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Figura 5");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
